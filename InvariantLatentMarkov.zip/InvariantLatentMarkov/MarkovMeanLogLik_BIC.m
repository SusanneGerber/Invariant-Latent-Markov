function [LogL,BIC] = MarkovMeanLogLik_BIC(X,P0)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
N=numel(X);

nn=size(P0,1);
LogL=0;
TT=0;

    for n=1:N
        T=length(X{n});
        TT=TT+T;
        for t1=2:T
            %if P0(X{n}(t1),X{n}(t1-1))>0
            LogL=LogL+log(max(P0(X{n}(t1),X{n}(t1-1)),1e-14));
            %end
        end
    end

N_par=2*sum(sum(abs(P0)>1e-5))-nn;
BIC=-2*LogL+N_par*log(TT);
LogL=LogL/TT;