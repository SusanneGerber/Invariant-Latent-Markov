function y=GenerateMarcovTrajectory(P,seed,T)
y=zeros(1,T);
y(1)=seed;
for i=1:T-1
%     if y(i)==0
%         keyboard
%     end
    [P1s,indP1s]=sort(P(y(i),:));
    P1s=cumsum(P1s);
    r=rand(1);
        [kk,mm_min]=find(P1s>r);
        if ~isempty(mm_min)
            y(i+1)=indP1s(min(mm_min));
        else
            y(i+1)=indP1s(1);
        end
        %      P1s(y(i),:)
        %      y(i+1)
 end

    