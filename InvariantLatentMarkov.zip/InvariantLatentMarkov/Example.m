
clear all
close all
clc

load('Data/asyn_a12_tip4p-d_torsion_sscont_tica_200clusters.mat')
%[V,D]=eig(cov(clustercenters));[mm,ii]=sort(diag(D),'descend');xx=V(:,ii(1:3))'*(clustercenters-mean(clustercenters')'*ones(1,size(clustercenters',1)))';figure;plot3(xx(1,:),xx(2,:),xx(3,:),'k.')
lag=21;
p_v=3/4;
TTT=0;TTT_valid=0;
for n=1:(lag)
    if n<=floor((lag-1)*p_v)
        Xf{n}=dtrajs(n:lag:length(dtrajs))+1;
        TTT=TTT+length(Xf{n});
    else
        Xf_valid{n-floor((lag-1)*p_v)}=dtrajs(n:lag:length(dtrajs))+1;
        TTT_valid=TTT_valid+length(Xf_valid{n-floor((lag-1)*p_v)});
    end
end

% p_v=3/4;
% TTT=0;TTT_valid=0;
% for n=1:(lag)
%         Xf{n}=dtrajs(n:lag:floor(p_v*length(dtrajs)))+1;
%         TTT=TTT+length(Xf{n});
%         Xf_valid{n}=dtrajs(floor(p_v*length(dtrajs))+1:lag:length(dtrajs))+1;
%         TTT_valid=TTT_valid+length(Xf_valid{n});
% end

 %T=length(Xf{1});
% Xf{1}=Xf{1}+1;
%end 
%N_train=T;
%figure(100);

N_traj_bs=200;
[P_cd0,N_cd0,mu,FPE, mu_pl,mu_mi,FPE_pl,FPE_mi, mu_f,FPE_f,mm,LogL  ] = EstimateUncertaintyMarkov_v2(Xf, N_traj_bs,'nsort');
[P_cd0_valid,N_cd0_valid,mu_valid,FPE_valid, mu_pl_valid,mu_mi_valid,...
    FPE_pl_valid,FPE_mi_valid, mu_f_valid,FPE_f_valid,mm_valid,LogL_valid  ] = EstimateUncertaintyMarkov_v2(Xf_valid, N_traj_bs,'nsort');
%St_Y0=St_Y0(:,mm)
[LogL,BIC_standard] = MarkovMeanLogLik_BIC(Xf,P_cd0)
[LogL_valid_standard,BIC_valid] = MarkovMeanLogLik_BIC(Xf_valid,P_cd0)
figure; hold on;for n=1:numel(mu_f),plot(mu_f{n},'b:');end;plot(mu,'k--','LineWidth',4);

%%%%%%%%%%%%%
IC='BIC';
K=[2:2:16 18 20 25 30 33 36 40 50 60 80 100];% 22 24 30 35 40 50];
clear gamma_init
% for kkk=1:length(K)
%     for n=1:50
%         [idx,c,sumd]=kmeans(clustercenters,K(kkk));
%         if n==1
%             idx_final=idx;
%             sumd_final=sum(sumd);
%         elseif sum(sumd)< sumd_final
%             idx_final=idx;
%             sumd_final=sum(sumd)
%         end
%     end
%     gamma_init{kkk}=zeros(K(kkk),size(clustercenters,1));
%     for t=1:length(idx)
%         gamma_init{kkk}(idx(t),t)=1;
%     end
% end
%save clustercenters clustercenters

N_anneal=400;
dt=1;
%%%%%%%%%%%%%
%[prob_term_topic, prob_topic_doc,lls] = plsa(N_cd0, 2);

%[out_max,mu_b,FPE_b, mu_pl_b,mu_mi_b,FPE_pl_b,FPE_mi_b, ...
%    mu_f_b,FPE_f_b, Information, LogL_b,LogL_f_b,Lambda,Gamma  ] =...
%    EstimateUncertaintyDBMR_v3(N_cd0, N_traj_bs,TTT,IC,K,N_anneal,Xf{1}(1));
 [out_max_plsa,mu_b_plsa,FPE_b, mu_pl_b_plsa,mu_mi_b_plsa,FPE_pl_b,FPE_mi_b, ...
     mu_f_b,FPE_f_b, Information, LogL_b,LogL_f_b,Lambda,Gamma,out,LogL_valid  ] =...
     EstimateUncertaintyPLSA_v1_crossvalid(N_cd0,N_cd0_valid, N_traj_bs,TTT,TTT_valid,IC,K,N_anneal,Xf{1}(1));
    figure;imagesc(out_max_plsa.gamma);
figure;plot(K,LogL_valid); hold on;plot(K,LogL_valid_standard*ones(size(K)),'--','LineWidth',2);   
figure(90);plot(K,Information,':.');hold on;plot(K,BIC_standard*ones(size(K)),'--','LineWidth',2);
%figure; hold on;for n=1:numel(LogL_f_b); lll(n)=LogL_f_b{n};end;plot(lll,'k--','LineWidth',4);plot(1:length(lll),LogL_b(length(LogL_b))*ones(1,length(lll)),'r--','LineWidth',4);
%figure; hold on;for n=1:numel(LogL_f_b);gg(n,:)=(Gamma{n}(1,:));end;mesh(gg)
%clear lam;figure; hold on;for n=1:numel(mu_f);lam(:,n)=(Lambda{n}(:,5));end;mesh(lam)
%plot(lll,'k--','LineWidth',4);
[~,mm]=sort(mu_b_plsa,'descend');
figure;hold on;
 for i=1:numel(out)
    mu_K(i,:)=out{i}.mu(mm);
 end
 plot(mu_K');hold on;plot(mu_b_plsa(mm),'r--','LineWidth',2)
[p0,pp,pm] = BernoulliConf(dtrajs,mm);
figure(100);hold on;%errorbar(1:length(mu),mu(mm),mu_mi(mm),mu_pl(mm),'r--');hold on;plot(mu(mm),'r:o','LineWidth',4);
errorbar(1:length(p0),p0,pp-p0,p0-pm,'g:','LineWidth',2);
%hold on;for n=1:numel(mu_f_b),plot(mu_f_b{n}(mm),'b:');end;
%errorbar(1:length(mu_b),mu_b(mm),mu_mi_b(mm),mu_pl_b(mm),'k--');%plot(1:length(p0),p0,'g:','LineWidth',4)
errorbar(1:length(mu_b_plsa),mu_b_plsa(mm),mu_mi_b_plsa(mm),mu_pl_b_plsa(mm),'m:');%plot(1:length(p0),p0,'g:','LineWidth',4)
plot(mu(mm),'k--','LineWidth',4);
%plot(mu_b(mm),'k--','LineWidth',4);
%[ out_max,Information ] = DBMR_function(N_cd0, TTT, St_Y,IC,K,N_anneal);
Gamma=out_max_plsa.gamma;lambda=out_max_plsa.P;P_K=Gamma*lambda;Permut_Index_For_Mu_only=mm;

pi0=zeros(size(Gamma,2),1);pi0(1)=1;
for i=1:10000
    pi0=lambda*Gamma*pi0;
end
hold on; plot(pi0(mm),'r--x','LineWidth',3)
mu_bmr=mu_b_plsa;P_full=lambda*Gamma;
[KK,SS]=meshgrid(K,1:length(p0));
figure;mesh(KK,SS,mu_K')
save MarkovLatentOptimal_K Gamma mu_bmr P_full lambda P_K Permut_Index_For_Mu_only


