function [p0,pp,pm] = BernoulliConf(X,mm)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
T=length(X);

for m=1:length(mm)
   p=length(find(X==mm(m)))/T;
   [p0(m),pp(m),pm(m)] = WilsonScore(p,T);
end

end

