function [N_par] = NparPLSA(lambda,gamma)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
tol=1e-5;
[mmm,kkk1]=size(lambda);
[kkk2,nnn]=size(gamma);
N_par=0;
for i=1:mmm
    ll=length(find(lambda(i,:)>tol));
    if ll<floor(kkk1/2)
        N_par=N_par+2*length(find(lambda(i,:)>tol))-1;
    else
        N_par=N_par+kkk1-1;
    end
end
for i=1:kkk2
    ll=length(find(gamma(i,:)>tol));
    if ll<floor(nnn/2)
        N_par=N_par+2*length(find(gamma(i,:)>tol))-1;
    else
        N_par=N_par+nnn-1;
    end
end
end

