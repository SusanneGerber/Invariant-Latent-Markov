function [out_max,mu,FPE, mu_pl,mu_mi,FPE_pl,FPE_mi, mu_f,FPE_f,BIC_plsa,LogL,LogL_unc,Lambda,Gamma,out,LogL_valid ] = EstimateUncertaintyPLSA_v1_crossvalid(N_cd0,N_cd0_valid, N_traj,T,T_valid,ic,k,n_anneal,seed_init)
%%
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
CI=0.95;eps=1e-3;
randn('seed',1)
rand('seed',1)
%if nargin<8
for k_i=1:length(k)
    k(k_i)
    for n=1:n_anneal
        [ out.P,out.gamma,LogL_ts ] = plsa(N_cd0,k(k_i),eps);
        N_par=NparPLSA(out.P,out.gamma);
         l_plsa(k_i,n)=LogL_ts(length(LogL_ts));
        if n==1
            out_max{k_i}=out;
            out_max{k_i}.mu=InvMeasureLatentCompute(out_max{k_i}.P,out_max{k_i}.gamma);
            LogL(k_i)=l_plsa(k_i,n);
            LogL_valid(k_i)=LogPLSA(out_max{k_i}.P,out_max{k_i}.gamma,N_cd0_valid,T_valid);
            BIC_plsa(k_i)=-2*l_plsa(k_i,n)+N_par*log(T);%+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);%+N_par*log(T);
       end
        if and(n>1,LogL(k_i)<l_plsa(k_i,n))
            LogL(k_i)=l_plsa(k_i,n);
            out_max{k_i}=out;
            out_max{k_i}.mu=InvMeasureLatentCompute(out_max{k_i}.P,out_max{k_i}.gamma);
            LogL_valid(k_i)=LogPLSA(out_max{k_i}.P,out_max{k_i}.gamma,N_cd0_valid,T_valid);
            BIC_plsa(k_i)=-2*l_plsa(k_i,n)+N_par*log(T);%+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);%N_par*log(T);
        end
    end
end

[~,ii]=min(BIC_plsa);
clear out
out=out_max;
out_max=out_max{ii};
%else
%    for kkk=1:length(k)
%        [idx,c]=kmeans(St_Y0',k(kkk));
%        gamma_init{kkk}=zeros(k(kkk),size(St_Y0,2));
%        for t=1:size(St_Y0,2)
%            gamma_init{kkk}(idx(t),t)=1;
%        end
%    end
%    for kkk=1:length(k)
%        if kkk==1
%            load gamma_init2;
%            gamma_init{kkk}=gamma_init2;
%            [ out_max,Information,LogL ] = DBMR_function(N_cd0, T, St_Y,ic,k,n_anneal,gamma_init);
%        else
%            [ out_max,Information,LogL ] = DBMR_function(N_cd0, T, St_Y,ic,k,n_anneal,gamma_init);
%        end
%    end
%end
[ mu,FPE ] = InvMeasureLatentCompute(out_max.P,out_max.gamma);
%FPE=D(2,2);

for n=1:1%N_traj
    Lambda{n}=out_max.P;
    Gamma{n}=out_max.gamma;
    seed{n}=seed_init;
    K{n}=size(Lambda{n},2);
    N_anneal{n}=1;
    TTT{n}=T;
    N_prior{n}=N_cd0;
end

%poolobj = parpool(12);
for nn=1:N_traj
    nn
    [~,~,mu_unc{nn},FPE_unc{nn},LogL_unc{nn}]=SingleBootstrapTrajectoryPLSA_v1(Lambda{1},...
        Gamma{1},seed{1},TTT{1},K{1},N_anneal{1},N_prior{1});
end
[~,mm]=sort(mu,'descend');
figure;hold on;
 for i=1:numel(mu_unc)
    plot(mu_unc{i}(mm));
 end
 plot(mu(mm),'r--','LineWidth',2);

 %delete(poolobj);
t=1;
for nn=1:N_traj
    nn
    if sum(double(abs(mu_unc{nn}-mu)>=10*abs(mu)))==0
        %P_f{t}=P_unc{nn};
        mu_f{t}=mu_unc{nn};
        FPE_f{t}=FPE_unc{nn};
        t=t+1
    end
end
N_traj=t-1;

[mu_pl,mu_mi]=EmpConfInt(mu,mu_f,CI);
[FPE_pl,FPE_mi]=EmpConfInt(FPE,FPE_f,CI);

end

