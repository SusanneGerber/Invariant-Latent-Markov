function [P_cd0,N_cd0,mu,FPE, mu_pl,mu_mi,FPE_pl,FPE_mi, mu_f,FPE_f,mm,LogL  ] = EstimateUncertaintyMarkov_v2(Xf, N_traj,sort_flag)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
CI=0.95;
[ N_cd0,P_cd0,LogL] = Continuous2DiscreteEnsembleBootstrap_v2(Xf,max(Xf{1}));
[V,D]=eig(full(P_cd0)); 
[mm,ii]=sort(abs(diag(D)),'descend');
%jj=find(mm==1);
V=V(:,ii);
mu=V(:,1);
%mu=zeros(1,nn);
mu=mu/sum(mu);
FPE=D(2,2);


T=0;
for t=1:numel(Xf)
    T=T+length(Xf{t});
end
for n=1:N_traj
    P{n}=P_cd0;
    TTT{n}=T;
    seed{n}=Xf{1}(1);
    %St{n}=St_Y;
end

%poolobj = parpool(12);
for nn=1:N_traj
    nn
    [P_unc{nn},mu_unc{nn},FPE_unc{nn}]=SingleBootstrapTrajectoryMarkov_v2(P{nn},seed{nn},TTT{nn});
end
%delete(poolobj);
t=1;
for nn=1:N_traj
    nn
    %if sum(double(abs(mu_unc{nn}-mu)>=10*abs(mu)))==0
        P_f{t}=P_unc{nn};
        mu_f{t}=mu_unc{nn};
        FPE_f{t}=FPE_unc{nn};
        t=t+1
    %end
end
N_traj=t-1;

[mu_pl,mu_mi]=EmpConfInt(mu,mu_f,CI);
[FPE_pl,FPE_mi]=EmpConfInt(FPE,FPE_f,CI);

if and(nargin>2,strcmp(sort_flag,'sort'))
[mu,mm]=sort(mu,'descend');
%St_Y=St_Y(:,mm);
mu_pl=mu_pl(mm);
mu_mi=mu_mi(mm);
N_cd0=N_cd0(mm,mm);
P_cd0=P_cd0(mm,mm);
for t=1:N_traj
   mu_f{t}=mu_f{t}(mm); 
end
end

