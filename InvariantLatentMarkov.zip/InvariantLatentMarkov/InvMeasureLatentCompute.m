function [ mu,FPE ] = InvMeasureLatentCompute(lambda,gamma)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

M0=(gamma*lambda);%MM0=out_max.P*out_max.gamma;

[V,D]=eig(full(M0)); 
[mm,ii]=sort(abs(diag(D)),'descend');
%jj=find(mm==1);
V=V(:,ii);D=diag(D);D=D(ii);

%[V,D]=eigs((M0)',2);
mus=V(:,1);
mus=mus/sum(mus);mu=lambda*mus;
FPE=D(2);
end

