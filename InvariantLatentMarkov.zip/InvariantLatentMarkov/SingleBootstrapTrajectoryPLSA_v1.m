function [Lambdax,Gammax,mu,FPE,LogL]=SingleBootstrapTrajectoryPLSA_v1(Lambda,Gamma,seed,TTT,K,N_anneal,N_prior)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%y{1}=GenerateDBMRTrajectory(Lambda,Gamma,seed,TTT);
seed=ceil(rand(1)*size(Lambda,1));
y{1}=GenerateMarcovTrajectory((Lambda*Gamma)',seed,TTT);
eps=1e-6;
%%% bin hier
[ N_cd0,~] = Continuous2DiscreteEnsembleBootstrap_v2(y,size(Lambda,1));
%[ out_max,~,LogL ] = DBMR_function_v3(N_cd0, TTT,IC,K,N_anneal,Gamma,Lambda);
ii=find(sum(N_cd0,1)==0);
for t=1:length(ii)
   N_cd0(:,ii(t))=N_prior(:,ii(t)); 
end
ii=find(sum(N_cd0,2)==0);
for t=1:length(ii)
   N_cd0(ii(t),:)=N_prior(ii(t),:); 
end
for n=1:N_anneal
    [ out.P,out.gamma,LogL ] = plsa(N_cd0,K,eps,Gamma,Lambda);
    if n==1
       l_plsa=LogL(length(LogL));
       out_max=out;
    end
    if and(n>1,l_plsa<LogL(length(LogL)))
        l_plsa=LogL(length(LogL));
        out_max=out;       
    end
end
Gammax=out_max.gamma;
Lambdax=out_max.P;
[ mu,FPE ] = InvMeasureLatentCompute(Lambdax,Gammax);

end

