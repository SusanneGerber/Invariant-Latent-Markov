function [ L ] = LogPLSA( lambda,gamma,N,T )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
M=lambda*gamma;
[I,J]=size(N);
L=0;
for i=1:I
    for j=1:J
        L=L+log(max(1e-13,M(i,j)))*N(i,j);
    end
end
L=L/T;
end

