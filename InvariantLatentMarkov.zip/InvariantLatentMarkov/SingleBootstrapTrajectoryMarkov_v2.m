function [P_cd0,mu,FBE] = SingleBootstrapTrajectoryMarkov_v2(P,seed,TTT )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
y{1}=GenerateMarcovTrajectory(P',seed,TTT);
[ ~, P_cd0] = Continuous2DiscreteEnsembleBootstrap_v2(y,size(P,1));
[V,D]=eig(full(P_cd0)); 
[mm,ii]=sort(abs(diag(D)),'descend');
%jj=find(mm==1);
V=V(:,ii);
mu=V(:,1);
mu=mu/sum(mu);
FBE=D(2,2);

end

