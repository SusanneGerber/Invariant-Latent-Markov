function [ N_ij,P,LogL] = Continuous2DiscreteEnsembleBootstrap_v2(X_disc,nn)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
N=numel(X_disc);


%nn=max(X_disc{1})-min(X_disc{1})+1;
%if nargout>2
    N_ij=zeros(nn,nn);
    for n=1:N
        T=length(X_disc{n});
        for t1=2:T
            N_ij(X_disc{n}(t1-1),X_disc{n}(t1))=N_ij(X_disc{n}(t1-1),X_disc{n}(t1))+1;
        end
    end
%end
P=eye(nn);
for i=1:nn
    ss=sum(N_ij(i,:));%ss_neg=sum(N_ij(i,setdiff(1:n,i)));
    if (ss>1e-12)%,ss_neg~=0)
        P(i,:)=N_ij(i,:)/ss;
    %elseif nargin>2  
    %    P(i,:)=P0(:,i)';
%    elseif ss_neg==0
%         N_ij(i,:)=N_ij(i,:)+1;
%         P(i,:)=N_ij(i,:)/sum(N_ij(i,:));
    else    
     %   P(i,:)=1/nn;
        %P(i,setdiff(1:n,i))=1e-7;
        %P(i,:)=P(i,:)/sum(P(i,:));
    end
end
%P=P+1e-7;
%for i=1:size(P,1)
%   P(i,:)=P(i,:)/sum(P(i,:)); 
%end

LogL=0;
for i=1:nn
    for j=1:nn
        if N_ij(i,j)>1e-12
        LogL=LogL+N_ij(i,j)*log(max(P(i,j)));
        end
    end
end
P=P';
